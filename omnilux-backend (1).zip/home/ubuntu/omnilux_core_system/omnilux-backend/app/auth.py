import os
import secrets
import hashlib
from datetime import datetime, timedelta
from flask import Blueprint, request, jsonify, url_for
from werkzeug.security import generate_password_hash, check_password_hash
import jwt
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import sqlite3
import re

auth_bp = Blueprint('auth', __name__)

# Configurações
SECRET_KEY = os.environ.get('SECRET_KEY', 'omnilux_quantum_key_432hz_12th_dimension')
DATABASE_PATH = 'omnilux_users.db'

# Configurações de e-mail (simuladas para demonstração)
EMAIL_CONFIG = {
    'smtp_server': 'smtp.gmail.com',
    'smtp_port': 587,
    'email': 'omnilux.system@gmail.com',
    'password': 'omnilux_quantum_password'
}

def init_database():
    """Inicializa o banco de dados com as tabelas necessárias"""
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    
    # Tabela de usuários
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            full_name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            account_type TEXT NOT NULL DEFAULT 'investor',
            is_verified BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            last_login TIMESTAMP,
            access_level TEXT DEFAULT 'basic'
        )
    ''')
    
    # Tabela de tokens de verificação
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS verification_tokens (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            token TEXT UNIQUE NOT NULL,
            token_type TEXT NOT NULL DEFAULT 'email_verification',
            expires_at TIMESTAMP NOT NULL,
            used BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')
    
    # Tabela de logs de auditoria
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS audit_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            action TEXT NOT NULL,
            details TEXT,
            ip_address TEXT,
            user_agent TEXT,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')
    
    # Criar usuário admin padrão se não existir
    cursor.execute('SELECT id FROM users WHERE email = ?', ('lumuralab@gmail.com',))
    if not cursor.fetchone():
        admin_password_hash = generate_password_hash('omnilux144@')
        cursor.execute('''
            INSERT INTO users (full_name, email, password_hash, account_type, is_verified, access_level)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', ('OMNI Root Admin', 'lumuralab@gmail.com', admin_password_hash, 'admin', True, 'admin'))
    
    conn.commit()
    conn.close()

def generate_verification_token():
    """Gera um token de verificação seguro"""
    return secrets.token_urlsafe(32)

def create_jwt_token(user_data):
    """Cria um JWT token para autenticação"""
    payload = {
        'user_id': user_data['id'],
        'email': user_data['email'],
        'access_level': user_data['access_level'],
        'exp': datetime.utcnow() + timedelta(hours=24),
        'iat': datetime.utcnow()
    }
    return jwt.encode(payload, SECRET_KEY, algorithm='HS256')

def validate_email(email):
    """Valida formato do e-mail"""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None

def validate_password(password):
    """Valida força da senha"""
    if len(password) < 8:
        return False, "Senha deve ter pelo menos 8 caracteres"
    if not re.search(r'[A-Za-z]', password):
        return False, "Senha deve conter pelo menos uma letra"
    if not re.search(r'[0-9]', password):
        return False, "Senha deve conter pelo menos um número"
    return True, "Senha válida"

def send_verification_email(email, full_name, verification_token):
    """Envia e-mail de verificação (simulado para demonstração)"""
    try:
        # Em produção, aqui seria a integração real com serviço de e-mail
        verification_url = f"https://tofgcupq.manus.space/verify-email?token={verification_token}"
        
        # Simular envio de e-mail
        print(f"[EMAIL SIMULADO] Enviando para: {email}")
        print(f"[EMAIL SIMULADO] Nome: {full_name}")
        print(f"[EMAIL SIMULADO] URL de verificação: {verification_url}")
        
        # Log da ação
        log_action(None, 'email_sent', f'Verification email sent to {email}', request.remote_addr, request.headers.get('User-Agent'))
        
        return True, "E-mail de verificação enviado com sucesso"
    except Exception as e:
        print(f"[EMAIL ERROR] Erro ao enviar e-mail: {str(e)}")
        return False, f"Erro ao enviar e-mail: {str(e)}"

def log_action(user_id, action, details, ip_address, user_agent):
    """Registra ação no log de auditoria"""
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO audit_logs (user_id, action, details, ip_address, user_agent)
        VALUES (?, ?, ?, ?, ?)
    ''', (user_id, action, details, ip_address, user_agent))
    conn.commit()
    conn.close()

@auth_bp.route('/register', methods=['POST'])
def register():
    """Endpoint para registro de novos usuários"""
    try:
        data = request.get_json()
        
        # Validação dos dados
        required_fields = ['fullName', 'email', 'password', 'confirmPassword', 'accountType', 'acceptTerms']
        for field in required_fields:
            if field not in data or not data[field]:
                return jsonify({'success': False, 'message': f'Campo {field} é obrigatório'}), 400
        
        # Validar e-mail
        if not validate_email(data['email']):
            return jsonify({'success': False, 'message': 'E-mail inválido'}), 400
        
        # Validar senha
        is_valid, message = validate_password(data['password'])
        if not is_valid:
            return jsonify({'success': False, 'message': message}), 400
        
        # Verificar se senhas coincidem
        if data['password'] != data['confirmPassword']:
            return jsonify({'success': False, 'message': 'Senhas não coincidem'}), 400
        
        # Verificar se aceita os termos
        if not data['acceptTerms']:
            return jsonify({'success': False, 'message': 'Você deve aceitar os termos e condições'}), 400
        
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        
        # Verificar se e-mail já existe
        cursor.execute('SELECT id FROM users WHERE email = ?', (data['email'],))
        if cursor.fetchone():
            conn.close()
            return jsonify({'success': False, 'message': 'E-mail já cadastrado'}), 400
        
        # Criar hash da senha
        password_hash = generate_password_hash(data['password'])
        
        # Inserir usuário
        cursor.execute('''
            INSERT INTO users (full_name, email, password_hash, account_type, is_verified, access_level)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (data['fullName'], data['email'], password_hash, data['accountType'], False, 'basic'))
        
        user_id = cursor.lastrowid
        
        # Gerar token de verificação
        verification_token = generate_verification_token()
        expires_at = datetime.utcnow() + timedelta(hours=24)
        
        cursor.execute('''
            INSERT INTO verification_tokens (user_id, token, token_type, expires_at)
            VALUES (?, ?, ?, ?)
        ''', (user_id, verification_token, 'email_verification', expires_at))
        
        conn.commit()
        conn.close()
        
        # Enviar e-mail de verificação
        email_sent, email_message = send_verification_email(data['email'], data['fullName'], verification_token)
        
        # Log da ação
        log_action(user_id, 'user_registered', f'New user registered: {data["email"]}', request.remote_addr, request.headers.get('User-Agent'))
        
        return jsonify({
            'success': True,
            'message': 'Cadastro realizado com sucesso! Verifique seu e-mail para confirmar a conta.',
            'email_sent': email_sent,
            'email_message': email_message,
            'verification_required': True
        }), 201
        
    except Exception as e:
        return jsonify({'success': False, 'message': f'Erro interno: {str(e)}'}), 500

@auth_bp.route('/login', methods=['POST'])
def login():
    """Endpoint para login de usuários"""
    try:
        data = request.get_json()
        
        if not data.get('email') or not data.get('password'):
            return jsonify({'success': False, 'message': 'E-mail e senha são obrigatórios'}), 400
        
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        
        # Buscar usuário
        cursor.execute('''
            SELECT id, full_name, email, password_hash, account_type, is_verified, access_level
            FROM users WHERE email = ?
        ''', (data['email'],))
        
        user = cursor.fetchone()
        
        if not user or not check_password_hash(user[3], data['password']):
            log_action(None, 'login_failed', f'Failed login attempt for {data["email"]}', request.remote_addr, request.headers.get('User-Agent'))
            conn.close()
            return jsonify({'success': False, 'message': 'Credenciais inválidas'}), 401
        
        # Verificar se e-mail foi verificado
        if not user[5]:  # is_verified
            conn.close()
            return jsonify({
                'success': False, 
                'message': 'E-mail não verificado. Verifique sua caixa de entrada.',
                'email_verification_required': True
            }), 401
        
        # Atualizar último login
        cursor.execute('UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = ?', (user[0],))
        conn.commit()
        conn.close()
        
        # Criar dados do usuário
        user_data = {
            'id': user[0],
            'full_name': user[1],
            'email': user[2],
            'account_type': user[4],
            'access_level': user[6]
        }
        
        # Gerar JWT token
        token = create_jwt_token(user_data)
        
        # Log da ação
        log_action(user[0], 'login_success', f'Successful login for {data["email"]}', request.remote_addr, request.headers.get('User-Agent'))
        
        return jsonify({
            'success': True,
            'message': 'Login realizado com sucesso',
            'token': token,
            'user': user_data
        }), 200
        
    except Exception as e:
        return jsonify({'success': False, 'message': f'Erro interno: {str(e)}'}), 500

@auth_bp.route('/verify-email', methods=['GET', 'POST'])
def verify_email():
    """Endpoint para verificação de e-mail"""
    try:
        token = request.args.get('token') or (request.get_json() or {}).get('token')
        
        if not token:
            return jsonify({'success': False, 'message': 'Token de verificação não fornecido'}), 400
        
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        
        # Buscar token
        cursor.execute('''
            SELECT vt.id, vt.user_id, vt.expires_at, vt.used, u.email, u.full_name
            FROM verification_tokens vt
            JOIN users u ON vt.user_id = u.id
            WHERE vt.token = ? AND vt.token_type = 'email_verification'
        ''', (token,))
        
        token_data = cursor.fetchone()
        
        if not token_data:
            conn.close()
            return jsonify({'success': False, 'message': 'Token de verificação inválido'}), 400
        
        # Verificar se token já foi usado
        if token_data[3]:  # used
            conn.close()
            return jsonify({'success': False, 'message': 'Token de verificação já foi utilizado'}), 400
        
        # Verificar se token expirou
        expires_at = datetime.fromisoformat(token_data[2].replace('Z', '+00:00'))
        if datetime.utcnow() > expires_at:
            conn.close()
            return jsonify({'success': False, 'message': 'Token de verificação expirado'}), 400
        
        # Marcar usuário como verificado
        cursor.execute('UPDATE users SET is_verified = TRUE WHERE id = ?', (token_data[1],))
        
        # Marcar token como usado
        cursor.execute('UPDATE verification_tokens SET used = TRUE WHERE id = ?', (token_data[0],))
        
        conn.commit()
        conn.close()
        
        # Log da ação
        log_action(token_data[1], 'email_verified', f'Email verified for {token_data[4]}', request.remote_addr, request.headers.get('User-Agent'))
        
        return jsonify({
            'success': True,
            'message': f'E-mail verificado com sucesso! Bem-vindo(a), {token_data[5]}!',
            'verified': True
        }), 200
        
    except Exception as e:
        return jsonify({'success': False, 'message': f'Erro interno: {str(e)}'}), 500

@auth_bp.route('/resend-verification', methods=['POST'])
def resend_verification():
    """Endpoint para reenvio de e-mail de verificação"""
    try:
        data = request.get_json()
        email = data.get('email')
        
        if not email:
            return jsonify({'success': False, 'message': 'E-mail é obrigatório'}), 400
        
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        
        # Buscar usuário
        cursor.execute('SELECT id, full_name, is_verified FROM users WHERE email = ?', (email,))
        user = cursor.fetchone()
        
        if not user:
            conn.close()
            return jsonify({'success': False, 'message': 'Usuário não encontrado'}), 404
        
        if user[2]:  # is_verified
            conn.close()
            return jsonify({'success': False, 'message': 'E-mail já verificado'}), 400
        
        # Invalidar tokens anteriores
        cursor.execute('''
            UPDATE verification_tokens 
            SET used = TRUE 
            WHERE user_id = ? AND token_type = 'email_verification' AND used = FALSE
        ''', (user[0],))
        
        # Gerar novo token
        verification_token = generate_verification_token()
        expires_at = datetime.utcnow() + timedelta(hours=24)
        
        cursor.execute('''
            INSERT INTO verification_tokens (user_id, token, token_type, expires_at)
            VALUES (?, ?, ?, ?)
        ''', (user[0], verification_token, 'email_verification', expires_at))
        
        conn.commit()
        conn.close()
        
        # Enviar e-mail
        email_sent, email_message = send_verification_email(email, user[1], verification_token)
        
        # Log da ação
        log_action(user[0], 'verification_resent', f'Verification email resent to {email}', request.remote_addr, request.headers.get('User-Agent'))
        
        return jsonify({
            'success': True,
            'message': 'E-mail de verificação reenviado com sucesso!',
            'email_sent': email_sent,
            'email_message': email_message
        }), 200
        
    except Exception as e:
        return jsonify({'success': False, 'message': f'Erro interno: {str(e)}'}), 500

@auth_bp.route('/forgot-password', methods=['POST'])
def forgot_password():
    """Endpoint para recuperação de senha"""
    try:
        data = request.get_json()
        email = data.get('email')
        
        if not email:
            return jsonify({'success': False, 'message': 'E-mail é obrigatório'}), 400
        
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        
        # Buscar usuário
        cursor.execute('SELECT id, full_name FROM users WHERE email = ?', (email,))
        user = cursor.fetchone()
        
        if not user:
            # Por segurança, não revelar se o e-mail existe ou não
            return jsonify({
                'success': True,
                'message': 'Se o e-mail estiver cadastrado, você receberá instruções para recuperação de senha.'
            }), 200
        
        # Gerar token de recuperação
        recovery_token = generate_verification_token()
        expires_at = datetime.utcnow() + timedelta(hours=2)  # Token expira em 2 horas
        
        cursor.execute('''
            INSERT INTO verification_tokens (user_id, token, token_type, expires_at)
            VALUES (?, ?, ?, ?)
        ''', (user[0], recovery_token, 'password_reset', expires_at))
        
        conn.commit()
        conn.close()
        
        # Simular envio de e-mail de recuperação
        print(f"[EMAIL SIMULADO] Recuperação de senha para: {email}")
        print(f"[EMAIL SIMULADO] Token: {recovery_token}")
        
        # Log da ação
        log_action(user[0], 'password_reset_requested', f'Password reset requested for {email}', request.remote_addr, request.headers.get('User-Agent'))
        
        return jsonify({
            'success': True,
            'message': 'Se o e-mail estiver cadastrado, você receberá instruções para recuperação de senha.'
        }), 200
        
    except Exception as e:
        return jsonify({'success': False, 'message': f'Erro interno: {str(e)}'}), 500

@auth_bp.route('/status', methods=['GET'])
def auth_status():
    """Endpoint para verificar status do sistema de autenticação"""
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    
    # Estatísticas básicas
    cursor.execute('SELECT COUNT(*) FROM users')
    total_users = cursor.fetchone()[0]
    
    cursor.execute('SELECT COUNT(*) FROM users WHERE is_verified = TRUE')
    verified_users = cursor.fetchone()[0]
    
    cursor.execute('SELECT COUNT(*) FROM verification_tokens WHERE used = FALSE AND expires_at > datetime("now")')
    pending_verifications = cursor.fetchone()[0]
    
    conn.close()
    
    return jsonify({
        'success': True,
        'system_status': 'online',
        'quantum_frequency': '432Hz',
        'dimension_active': '12th',
        'certification': 'PLATINUM (94.7/100)',
        'statistics': {
            'total_users': total_users,
            'verified_users': verified_users,
            'pending_verifications': pending_verifications,
            'verification_rate': f"{(verified_users/total_users*100):.1f}%" if total_users > 0 else "0%"
        }
    }), 200

# Inicializar banco de dados quando o módulo for importado
init_database()

